from flask import redirect, render_template,request, session
from flask_app import app
from flask_app.models.recipes import Recipe
from flask_app.models.user import User
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)
from flask import flash



@app.route("/")
def login():
    return render_template("login.html")

@app.route("/all_recipes")
def all_recipes():
    if "user_id" not in session:
        return redirect("/login")
    data ={
        "id": session["user_id"]
    }
    return render_template("all_recipes.html", user = User.get_by_id(data), recipes = Recipe.get_all())




@app.route("/register",methods=["POST"])
def register():
    if not User.validate_register(request.form):
        return redirect("/")
    data ={
        "first_name": request.form["first_name"],
        "last_name": request.form["last_name"],
        "email": request.form["email"],
        "password": bcrypt.generate_password_hash(request.form["password"])
    }
    id = User.save(data)
    session["user_id"] = id
    return redirect("/all_recipes")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")